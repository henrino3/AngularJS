angular.module('mrPredict', [ 'starter.controllers','ngRoute'])

.run(function($rootScope) {
  $rootScope.hello = function() {
    console.log('hello');
  }
});

.config( function($routeProvider) { 
  $routeProvider
  .when('/', {
    templateUrl: 'templates/home.html',
    controller: 'HomeController'
  })
  .when('/about', {
    templateUrl: 'templates/about.html',
    controller: 'AboutController'
  })
})
/*
.config( function($httpProvider) {
        $httpProvider.defaults.useXDomain = true;
        delete $httpProvider.defaults.headers.common['X-Requested-With'];
    }
)*/